// HomePage.jsx
import React from "react";

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to My React App</h1>
      <p>This is the homepage of my React application.</p>
      
    </div>
  );
};

export default HomePage;
