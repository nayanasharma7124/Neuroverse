/// <reference types="react-scripts" />
declare module "*.ogg";
